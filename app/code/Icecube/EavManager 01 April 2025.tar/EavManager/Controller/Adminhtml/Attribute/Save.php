<?php
 
namespace Icecube\EavManager\Controller\Adminhtml\Attribute;
 
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Customer\Model\Customer;
use Magento\Customer\Setup\CustomerSetup;
use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Eav\Model\Entity\Attribute\Set;
use Magento\Eav\Model\Entity\Attribute\SetFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Exception\LocalizedException;
use Icecube\EavManager\Model\EavManagerFactory;
use Icecube\EavManager\Model\ResourceModel\EavManager;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Message\ManagerInterface;

// use Magento\Eav\Model\Config;
// use Magento\Eav\Model\Entity\Attribute;
// use Magento\Eav\Model\Entity\TypeFactory;

 
 
class Save extends Action
{
    protected $eavManagerFactory;
    protected $resourceModel;
    protected $resultRedirectFactory;
    protected $messageManager;
    private  $customerSetupFactory;
    private  $attributeSetFactory;
 
    public function __construct(
        Context $context,
        CustomerSetupFactory $customerSetupFactory,
        SetFactory $attributeSetFactory,
        EavManagerFactory $eavManagerFactory,
        EavManager $resourceModel,
        RedirectFactory $resultRedirectFactory,
        ManagerInterface $messageManager,
       
       
    ) {
        parent::__construct($context);
        $this->eavManagerFactory = $eavManagerFactory;
        $this->resourceModel = $resourceModel;
        $this->resultRedirectFactory = $resultRedirectFactory;
        $this->messageManager = $messageManager;
        $this->customerSetupFactory = $customerSetupFactory;
        $this->attributeSetFactory = $attributeSetFactory;
    }
 
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        echo "<pre>"; print_r($data);
       if (!$data) {
            $this->messageManager->addErrorMessage(__('No data received.'));
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        }

        // ============================ Attribute Code Validation Start ============================
        // Validate attribute code  
         $attribute_code = $data['Properties']['attribute_code']; // Attribute code
        if (empty( $attribute_code)) {
            $this->messageManager->addErrorMessage(__('Attribute code is required.'));
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        }
        if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/',  $attribute_code)) {
            $this->messageManager->addErrorMessage(__('Attribute code must start with a letter or underscore and can only contain letters, numbers, and underscores.'));
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        }
        // ============================ Attribute Code Validation End ============================
 
        // =============================== Frontend Lebel Validation Start  ===============================
           // Default label
            $defaultLabel = $data['Properties']['default_label']; // Default label
            $frontendLabels = $data['frontend_label'];
           // Sirf non-empty values rakhna
            $frontendLabels = array_filter($frontendLabels, function ($label) {
                return !empty($label);
            });

            // Agar koi non-empty value nahi hai to empty array set karna
            if (empty($frontendLabels)) {
                $frontendLabels = [];
            }

        // =============================== Frontend Lebel Validation End  ===============================



        // =============================== Backend Type Validation Start  ===============================
        
          // Backend Type Mapping Based on frontend_input
            $backendTypeMapping = [
                'text'         => 'varchar',
                'textarea'     => 'text',
                'texteditor'   => 'text',
                'date'         => 'datetime',
                'boolean'      => 'int',
                'multiselect'  => 'text',
                'select'       => 'int',
                'radio'        => 'int',
                'checkbox'     => 'text',
                'image'        => 'varchar',
                'file'         => 'varchar',
                'video'        => 'varchar',
                'audio'        => 'varchar',
                'time_picker'  => 'varchar',
                'color_picker' => 'varchar'
            ];

            // ** Validate and Set Backend Type **
            $frontendInput = $data['Properties']['frontend_input'] ?? 'text'; // Default text
            $backendType = $backendTypeMapping[$frontendInput] ?? 'varchar';  // Default varchar
        // =============================== Backend Lebel Validation  End    ===============================


       // =============================== Frontend Input Validation Start  ===============================
            $frontendTypeMapping = [
                'text'         => 'text',
                'textarea'     => 'textarea',
                'texteditor'   => 'textarea',  
                'date'         => 'date',
                'boolean'      => 'boolean',
                'multiselect'  => 'multiselect',
                'select'       => 'select',
                'radio'        => 'select',  
                'checkbox'     => 'multiselect', 
                'file'         => 'file',   
                'audio'        => 'file',    
                'time_picker'  => 'text',  
                'color_picker' => 'text'   
            ];

            // ** Validate and Set Frontend Type **
            $frontendInput = $data['Properties']['frontend_input'] ?? 'text'; // Default text
            $inputType = $frontendTypeMapping[$frontendInput] ?? 'text';  // Default text

     // =============================== Frontend Input Validation  End    ===============================


       // =============================== Used in Grid  Validation Start  ===============================
             $used_in_grid = $data['advanced_attribute_properties']['is_used_in_customer_grid'] ?? 0; // Default 0
             $used_in_sales_grid = $data['advanced_attribute_properties']['is_used_in_sales_grid'];

       // =============================== Used in Grid  Validation End  ===============================

       
         // =============================== Sort Order Validation Start  ===============================
         $sortOrder = !empty($data['storefront_properties']['sort_order']) 
         ? (int) $data['storefront_properties']['sort_order'] 
         : 0;
        // =============================== Sort Order Validation End  ===============================
       


 
        try {
              // Get customer setup and entity type
            $customerSetup = $this->customerSetupFactory->create();
            $customerEntity = $customerSetup->getEavConfig()->getEntityType(Customer::ENTITY);
            $attributeSetId = $customerEntity->getDefaultAttributeSetId();

             // Get the default attribute group
             $attributeSet = $this->attributeSetFactory->create();
             $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);


             // Add a custom attribute dynamically
            $customerSetup->addAttribute(
                Customer::ENTITY,
                $attribute_code,
                [
                    'label' =>  $defaultLabel, // Default label for global store
                    'input' => $inputType,
                    'type' => $backendType,
                    'required' => $data['advanced_attribute_properties']['is_required'],
                    'position' => $sortOrder,
                    'visible' => $data['storefront_properties']['show_on_storefront'],
                    'default' => $data['Properties']['default_value'] ?? '',
                    'user_defined' => 1,
                    'system' => false,
                    'is_used_in_grid' => $used_in_grid,
                    'is_visible_in_grid' => $used_in_grid,
                    'is_filterable_in_grid' => $used_in_grid,
                    'is_searchable_in_grid' => $used_in_grid,
                    'backend' => '',
                ]
            );

        

            // Get the added attribute
            $attribute = $customerSetup->getEavConfig()->getAttribute(Customer::ENTITY,  $attribute_code);
             
            if ($frontendLabels) {
                $attribute->setData('store_labels', $frontendLabels);
            }
            
            // Set additional data for the attribute
            // ===============================  shown on Forms Validation Start  ===============================
            $showOnForms = $data['storefront_properties']['show_on_forms'] ?? []; // Default empty array
            // =============================== shown on Forms  Validation End  ===============================
            if($showOnForms){
                $attribute->addData([
                    'used_in_forms' => $showOnForms
                ]);
            }
           
            $attribute->addData([
                'attribute_set_id' => $attributeSetId,
                'attribute_group_id' => $attributeGroupId
            ]);
            $attribute->save();

           
 
            // Step 3: Save in Custom Table
            $customAttribute = $this->eavManagerFactory->create();
            $customAttribute->setData([
                'entity_type_id' => $customerEntity->getId(),
                'attribute_id' => $attribute->getId(),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ]);
            $this->resourceModel->save($customAttribute);
            exit;
            // Success message
            $this->messageManager->addSuccessMessage(__('Attribute has been created.'));
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }
 
        return $this->resultRedirectFactory->create()->setPath('*/*/');
    }
}


// Table names
// 1.eav_attribute
// 2.customer_eav_attribute_website
// 3. eav_attribute_label
// 4. eav_entity_type
// 5. customer_entity_varchar
// 6. customer_entity_text
// 7. customer_group
// 8. customer_form_attribute
// 9. customer_eav_attribute
// 10. customer_entity_datetime