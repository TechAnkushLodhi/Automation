<?php
/**
 * Copyright © Icecube Digital All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Icecube\EavManager\Model\EavManager;

use Icecube\EavManager\Model\ResourceModel\EavManager\CollectionFactory;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\CollectionFactory as AttributeCollectionFactory;

class DataProvider extends AbstractDataProvider
{
    protected $collection;
    protected $attributeCollectionFactory;

    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        AttributeCollectionFactory $attributeCollectionFactory, 
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        $this->attributeCollectionFactory = $attributeCollectionFactory;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }
    

    public function getData()
    {
        $items = $this->collection->getItems();
    
        $attributeIds = [];
        foreach ($items as $item) {
            $attributeIds[] = $item->getAttributeId();
        }
    
        if (!empty($attributeIds)) {
            $attributeCollection = $this->attributeCollectionFactory->create();
            $attributeCollection->addFieldToFilter('attribute_id', ['in' => $attributeIds]);
    
            $attributeData = [];
            foreach ($attributeCollection as $attribute) {
                $attributeData[$attribute->getId()] = [
                    'attribute_code'  => $attribute->getAttributeCode(),
                    'frontend_label'  => $attribute->getFrontendLabel(),
                    'backend_type'    => $attribute->getBackendType(),
                    'frontend_input'  => $attribute->getFrontendInput(),
                    'default_value'   => $attribute->getDefaultValue(),
                    'is_required'     => $attribute->getIsRequired(),
                ];
            }
    
            foreach ($items as $item) {
                $attrId = $item->getAttributeId();
                if (isset($attributeData[$attrId])) {
                    $item->setData(array_merge($item->getData(), $attributeData[$attrId]));
                }
            }
        }
    //    echo '<pre>';
    //    print_r($items);die;
        return [
            'totalRecords' => count($items),
            'items' => array_values($items), 
        ];
    }
    

    
}
