<?php
namespace Icecube\EavManager\Model\ResourceModel\EavManager\Grid;

use Magento\Framework\View\Element\UiComponent\DataProvider\SearchResult;

class Collection extends SearchResult
{
}
