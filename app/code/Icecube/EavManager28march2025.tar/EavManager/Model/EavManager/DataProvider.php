<?php
/**
 * Copyright © Icecube Digital All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Icecube\EavManager\Model\EavManager;

use Icecube\EavManager\Model\ResourceModel\EavManager\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;

class DataProvider extends AbstractDataProvider
{
    protected $collection;
    protected $dataPersistor;
    protected $loadedData;

    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        DataPersistorInterface $dataPersistor,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
    
        $items = $this->collection->getItems();
        foreach ($items as $item) {
            $data = $item->getData();
            $itemId = $item->getId();
            if (!empty($data) && $itemId !== null) {
                $this->loadedData[$itemId] = $data;
            }
        }
    
        $data = $this->dataPersistor->get("icecube_eavmanager");
        if (!empty($data)) {
            $attribute = $this->collection->getNewEmptyItem();
            $attribute->setData($data);
            $this->loadedData[$attribute->getId()] = $data;
            $this->dataPersistor->clear("icecube_eavmanager");
        }
    
        // Debugging Log
        if (empty($this->loadedData)) {
            error_log("DataProvider getData() returned empty data.");
        }
    
        return $this->loadedData ?? [];
    }
    
}
