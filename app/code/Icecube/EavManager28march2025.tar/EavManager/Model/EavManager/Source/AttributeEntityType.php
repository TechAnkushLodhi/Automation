<?php
/**
 * Copyright © Icecube Digital All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);
namespace Icecube\EavManager\Model\EavManager\Source;

use Magento\Eav\Model\Entity\Attribute\Source\AbstractSource;

class AttributeEntityType extends AbstractSource
{
    /**
     * Get all options
     *
     * @return array
     */
    public function getAllOptions()
    {
        if ($this->_options === null) {
            $this->_options = [
                ['label' => __('Customer'), 'value' => 'customer'],
                ['label' => __('Customer Address'), 'value' => 'customer_address'],
                ['label' => __('Product'), 'value' => 'catalog_product'],
                ['label' => __('Category'), 'value' => 'catalog_category'],
                ['label' => __('Order'), 'value' => 'order'],
                ['label' => __('Invoice'), 'value' => 'invoice'],
                ['label' => __('Creditmemo'), 'value' => 'creditmemo'],
                ['label' => __('Shipment'), 'value' => 'shipment'],

            ];
        }
        return $this->_options;
    }
}