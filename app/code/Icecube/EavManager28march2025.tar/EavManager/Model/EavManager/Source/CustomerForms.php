<?php
/**
 * Copyright © Icecube Digital All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Icecube\EavManager\Model\EavManager\Source;

use Magento\Framework\Data\OptionSourceInterface;

class CustomerForms implements OptionSourceInterface
{
    public function toOptionArray()
    {
        return [
            ['value' => 'customer_account_create', 'label' => __('Customer Account Create')],
            ['value' => 'customer_account_edit', 'label' => __('Customer Account Edit')],
            ['value' => 'adminhtml_checkout', 'label' => __('Admin Checkout')],
            ['value' => 'adminhtml_customer', 'label' => __('Adminhtml Customer')]
        ];
    }
}
