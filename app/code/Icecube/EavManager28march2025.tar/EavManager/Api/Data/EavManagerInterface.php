<?php
namespace Icecube\EavManager\Api\Data;

interface EavManagerInterface
{
    const ID = 'entity_id';
    const ATTRIBUTE_ID = 'attribute_id';  
    const EAV_ENTITY_TYPE = 'eav_entity_type';
    const ATTRIBUTE_CODE = 'attribute_code';
    const STORE_ID = 'store_id';
    const VALUE = 'value';

    /**
     * Get ID
     * @return int|null
     */
    public function getId();

    /**
     * Set ID
     * @param int $id
     * @return \Icecube\EavManager\Api\Data\EavManagerInterface
     */
    public function setId(?int $id);

    /**
     * Get Attribute ID
     * @return int
     */
    public function getEavAttributeId();

    /**
     * Set Attribute ID
     * @param int $attributeId
     * @return \Icecube\EavManager\Api\Data\EavManagerInterface
     */
    public function setEavAttributeId($attributeId);

    /**
     * Get EAV Entity Type
     * @return string
     */
    public function getEavEntityType();

    /**
     * Set EAV Entity Type
     * @param string $eavEntityType
     * @return \Icecube\EavManager\Api\Data\EavManagerInterface
     */
    public function setEavEntityType($eavEntityType);

    /**
     * Get Attribute Code
     * @return string
     */
    public function getAttributeCode();

    /**
     * Set Attribute Code
     * @param string $attributeCode
     * @return \Icecube\EavManager\Api\Data\EavManagerInterface
     */
    public function setAttributeCode($attributeCode);

    /**
     * Get Store ID
     * @return int[]
     */
    public function getStoreId();

    /**
     * Set Store ID
     * @param int[] $storeId
     * @return \Icecube\EavManager\Api\Data\EavManagerInterface
     */
    public function setStoreId($storeId);

    /**
     * Get Value
     * @return string
     */
    public function getValue();

    /**
     * Set Value
     * @param string $value
     * @return \Icecube\EavManager\Api\Data\EavManagerInterface
     */
    public function setValue($value);
}
?>

