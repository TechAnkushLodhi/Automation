<?php
 
namespace Icecube\EavManager\Controller\Adminhtml\Attribute;
 
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Eav\Model\Entity\Attribute;
use Magento\Eav\Model\Entity\TypeFactory;
use Icecube\EavManager\Model\EavManagerFactory;
use Icecube\EavManager\Model\ResourceModel\EavManager;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Message\ManagerInterface;
 
 
class Save extends Action
{
    protected $attribute;
    protected $eavManagerFactory;
    protected $resourceModel;
    protected $resultRedirectFactory;
    protected $messageManager;
    protected $typeFactory;
 
    public function __construct(
        Context $context,
        Attribute $attribute,
        EavManagerFactory $eavManagerFactory,
        EavManager $resourceModel,
        RedirectFactory $resultRedirectFactory,
        ManagerInterface $messageManager,
        TypeFactory $typeFactory
    ) {
        parent::__construct($context);
        $this->attribute = $attribute;
        $this->eavManagerFactory = $eavManagerFactory;
        $this->resourceModel = $resourceModel;
        $this->resultRedirectFactory = $resultRedirectFactory;
        $this->messageManager = $messageManager;
        $this->typeFactory = $typeFactory;
    }
 
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        echo "<pre>"; print_r($data); exit;
        if (!$data) {
            $this->messageManager->addErrorMessage(__('No data received.'));
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        }
 
        // =============================== Frontend Lebel Validation Start  ===============================
           // Default label
            $frontendLabels = [];
 
            // Default label (for store_id 0)
            $frontendLabels[0] = $data['default_label']; // Global store (0)
 
            // Store-wise frontend labels if provided
            if (isset($data['frontend_label']) && is_array($data['frontend_label'])) {
                foreach ($data['frontend_label'] as $storeId => $label) {
                    // Check if label is set for the specific store ID, if not, fallback to default_label
                    $frontendLabels[$storeId] = $label ?: $data['default_label'];
                }
            }else{
                // Default fallback if no frontend_label array provided
                $frontendLabels[0] = $data['default_label']; // Global store fallback
               }
        // =============================== Frontend Lebel Validation Start  ===============================
 
        try {
            // Step 1: Entity Type ID
            $entityType = $this->typeFactory->create()->loadByCode($data['entity_type']);
            $entityTypeId = $entityType->getId();
 
            // Step 2: Create Attribute in EAV
            $attribute = $this->attribute;
            $attribute->setData([
                'entity_type_id' => $entityTypeId,
                'attribute_code' => $data['attribute_code'],
                'frontend_label' => $frontendLabels,
                'backend_type' => 'varchar',
                'frontend_input' => $data['frontend_input'],
                'is_user_defined' => 1,
                'is_visible' =>$data['show_on_storefront'],
                'is_required' => 0,
                'is_unique' => 0,
            ]);
            $attribute->save();
 
            // Step 3: Save in Custom Table
            $customAttribute = $this->eavManagerFactory->create();
            $customAttribute->setData([
                'entity_type_id' => $entityTypeId,
                'attribute_id' => $attribute->getId(),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ]);
            $this->resourceModel->save($customAttribute);
 
            $this->messageManager->addSuccessMessage(__('Attribute has been created and saved in icecube_eav_manager table.'));
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }
 
        return $this->resultRedirectFactory->create()->setPath('*/*/');
    }
}


// Table names
// 1.eav_attribute
// 2.customer_eav_attribute_website
// 3. eav_attribute_label
// 4. eav_entity_type
// 5. customer_entity_varchar
// 6. customer_entity_text
// 7. customer_group
// 8. customer_form_attribute
// 9. customer_eav_attribute
// 10. customer_entity_datetime