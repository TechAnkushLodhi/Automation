<?php

namespace Icecube\EavManager\Model\EavManager;

use Icecube\EavManager\Model\ResourceModel\EavManager\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\CollectionFactory as AttributeCollectionFactory;


class DataProvider extends AbstractDataProvider
{
    protected $collection;
    protected $dataPersistor; 
    protected $storeManager;
    protected $attributeCollectionFactory;
    protected $attribute;
    protected $loadedData = [];

    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,  // 🔹 Corrected variable name
        AttributeCollectionFactory $attributeCollectionFactory, // 🔹 Added for attribute collection
        DataPersistorInterface $dataPersistor,
        StoreManagerInterface $storeManager,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        $this->attributeCollectionFactory = $attributeCollectionFactory;
        $this->dataPersistor = $dataPersistor;
        $this->storeManager = $storeManager;

        parent::__construct(
            $name,
            $primaryFieldName,
            $requestFieldName,
            $meta,
            $data
        );

        $this->meta = $this->prepareMeta($this->meta);
    }

    public function prepareMeta(array $meta)
    {
        return $meta;
    }

    public function getData()
    {
        if (!empty($this->loadedData)) {
            return $this->loadedData;
        }
    
        // Fetch all items from custom collection
        $items = $this->collection->getItems();
    
        foreach ($items as $item) {
            // Get custom data
            $customData = $item->getData();

            // Disable field when we edit the attribute
            $customData['is_disabled'] = true;

           
           
            // Join `eav_attribute` table based on `attribute_id`
            $attributeId = $customData['attribute_id']; // Assuming 'attribute_id' is the field in your custom table
            $eavAttribute = $this->getEavAttributeData($attributeId);


            $AttributeFormCode = $this->getEavAttributeFormCode($attributeId);
             if(isset($AttributeFormCode['show_on_forms'])){
                $customData['show_on_forms'] = $AttributeFormCode['show_on_forms'];
             }else{
                $customData['show_on_forms'] = null;
             }
           
            // Merge custom data with EAV attribute data
            if (isset($eavAttribute[0])) {
                foreach ($eavAttribute[0] as $key => $value) {
                    $customData[$key] = $value;
                }
                $this->loadedData[$item->getId()] = $customData;
            } else {
                $this->loadedData[$item->getId()] = $customData;
            }
        }
        // Persisted data (if any)
        $data = $this->dataPersistor->get("Icecube_EavManager");
        if (!empty($data)) {
            $eavAttribute = $this->collection->getNewEmptyItem();
            $eavAttribute->setData($data);
            $this->loadedData[$eavAttribute->getId()] = $data;
            $this->dataPersistor->clear("Icecube_EavManager");
        }
        return $this->loadedData;
    }
    
    /**
     * Function to get EAV attribute data based on attribute_id
     */
    protected function getEavAttributeData($attributeId)
    {
        // Fetch the EAV attribute collection
        $eavAttributeCollection = $this->attributeCollectionFactory->create();
    
        $eavAttributeCollection->joinLeft(
            ['cea' => 'customer_eav_attribute'], // Alias 'cea' for the table
            'main_table.attribute_id = cea.attribute_id', // Join condition
            ['is_visible', 'is_used_in_grid','sort_order'] // Specific columns to fetch
        );
        // Add a filter to get only the specific attribute by attribute_id
        $eavAttributeCollection->addFieldToFilter('main_table.attribute_id', $attributeId); 
        return $eavAttributeCollection->getData();
    }

    protected function getEavAttributeFormCode($attributeId){
         // Fetch the EAV attribute collection
         $eavAttributeCollection = $this->attributeCollectionFactory->create();
         $eavAttributeCollection->joinLeft(
            ['customerform' => 'customer_form_attribute'], // Alias 'cea' for the table
            'main_table.attribute_id = customerform.attribute_id', // Join condition
            ['form_code'] // Specific columns to fetch
         );
        // Add a filter to get only the specific attribute by attribute_id
        $eavAttributeCollection->addFieldToFilter('main_table.attribute_id', $attributeId);
        $FormCodeData = [];
        foreach ($eavAttributeCollection->getData() as $data) {
            $FormCodeData['show_on_forms'][] = $data['form_code'];
        }
        return  $FormCodeData ?? null;
    }
    

   
    
}
