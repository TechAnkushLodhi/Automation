<?php
namespace Icecube\EavManager\Block\Customer\Attributes;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Icecube\EavManager\Helper\Data;
use Icecube\EavManager\Model\EavManagerFactory;
use Magento\Customer\Model\ResourceModel\Attribute\CollectionFactory as CustomerAttributeCollectionFactory;

class Fields extends Template
{
    /**
     * @var Data
     */
    protected $helper;

    protected $eavManagerFactory;

    /**
     * @var CustomerAttributeCollectionFactory
     */
    protected $customerAttributeCollectionFactory;

    /**
     * Fields constructor.
     *
     * @param Context $context
     * @param Data $helper
     * @param EavManagerFactory $eavManagerFactory
     * @param CustomerAttributeCollectionFactory $customerAttributeCollectionFactory
     * @param array $data
     */
    public function __construct(
        Context $context,
        Data $helper,
        EavManagerFactory $eavManagerFactory,
        CustomerAttributeCollectionFactory $customerAttributeCollectionFactory,
        array $data = []
    ) {
        $this->helper = $helper;
        $this->eavManagerFactory = $eavManagerFactory->create();
        $this->customerAttributeCollectionFactory = $customerAttributeCollectionFactory;
        parent::__construct($context, $data);
    }

    /**
     * Get custom value
     *
     * @return string
     */
    public function getCustomValue()
    {   
        $IsEnabled = $this->helper->isModuleEnabled();
        if ($IsEnabled) {
            return 'This is a custom field!';
        }
    }

    public function getEavManager()
    {
        $eavManager = $this->eavManagerFactory->getCollection();  // Get the collection of icecuebe_eav_manager table
        $EavAtributesIds = [];
        foreach ($eavManager as $item) {
            $EavAtributesIds[] = $item->getEavAttributeId();
        }
        echo "<pre>";
        print_r($this->getCustomerAttributes());
        echo "</pre>";
        die();
        return $eavManager->getCollection()->getData();
    }

    protected function getCustomerAttributes()
    {
        $customerAttributes = $this->customerAttributeCollectionFactory->create();
        $attributesData = [];
        foreach ($customerAttributes as $attribute) {
            echo "<pre>";
            print_r($attribute->getData());
            echo "</pre>";
            $attributesData[] = [
                'attribute_code' => $attribute->getAttributeCode(),
                'frontend_label' => $attribute->getFrontendLabel(),
            ];
        }
        return $attributesData;
    }
}
