<?php
namespace Icecube\EavManager\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\ResourceConnection;

class Data extends AbstractHelper
{
    /**
     * @var ResourceConnection
     */
    protected $resourceConnection;

    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        ResourceConnection $resourceConnection
    ) {
        parent::__construct($context);
        $this->resourceConnection = $resourceConnection;
    }

    /**
     * Save store-wise labels for attribute
     *
     * @param \Magento\Eav\Model\Entity\Attribute $attribute
     * @param array $storeLabels
     * @return void
     */
    public function saveStoreLabels(\Magento\Eav\Model\Entity\Attribute $attribute, array $storeLabels)
    {
        $connection = $this->resourceConnection->getConnection();
        $attributeId = $attribute->getId();

        if ($attributeId) {
            $condition = ['attribute_id =?' => $attributeId];
            $connection->delete('eav_attribute_label', $condition);
        }
        foreach ($storeLabels as $storeId => $label) {
            if ($storeId == 0 || $label === null || !strlen($label)) {
                continue;
            }

            $bind = [
                'attribute_id' => $attributeId,
                'store_id' => $storeId,
                'value' => $label
            ];

            $connection->insert('eav_attribute_label', $bind);
        }
    }
}


?>